//@author vidula IT18026962
package com.oop.model;

public class Search {
	
	private String search;

	public String getSearch() {
		return search;
	}

	public void setSearch(String search) {
		this.search = search;
	}
	

	

}
