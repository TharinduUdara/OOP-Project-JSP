
//** School Information Management System**//
Metro weekend Batch

project ID: - METRO_WE_6

#########################################################
Student ID   	# MEMBERS			 	#
#########################################################		
		#				 	#
IT18038606	# Gomez. K. J (Leader) 071-5185863 	# 
		#				 	#
IT18026962	# Dantanarayana. V. D		 	#
		#				 	#
IT18045840	# Dissanayake. S. D. S. L	 	#
		#				 	#
IT18153132	# Perera. L. M. D		 	#
		#				 	#
#########################################################	


Please Kindly note that you are not required to create any Database... As they are subjected to auto creation.

Current Database logins are 

username:- root
password:- root


If any changes needed to be made kindly update the relavant username,password in the config.properties file in com.oop.util....